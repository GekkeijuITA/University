void divide(int a , int b , int& q , int& r)
{
    q = a/b;
    r = a%b;
}