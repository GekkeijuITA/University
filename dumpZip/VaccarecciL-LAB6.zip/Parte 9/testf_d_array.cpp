#include "d_array.h"

int main()
{
    dynamic_array a;

    read_d_array(a);
    print_d_array(a);

    return 0;
}