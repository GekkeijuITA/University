#include "iovector.h"
using namespace std;

int main()
{
    vector<int> v;
    readVector(v);
    printVector(v);
    return 0;
}