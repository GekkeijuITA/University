#include <vector>
using namespace std;
vector<int> insert(vector<int>&,int,int);