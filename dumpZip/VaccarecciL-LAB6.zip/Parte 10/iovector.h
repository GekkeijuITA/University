#include <iostream>
#include <vector>
using namespace std;

void readVector(vector<int>&);
void printVector(const vector<int>&);
vector<int> reverse(vector<int>&);