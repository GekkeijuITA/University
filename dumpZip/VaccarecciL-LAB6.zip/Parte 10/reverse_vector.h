#include <vector>
using namespace std;

vector<int> reverse(vector<int>&);