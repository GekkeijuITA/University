#include <vector>
using namespace std;
vector<int> cat(vector<int>&,vector<int>&);